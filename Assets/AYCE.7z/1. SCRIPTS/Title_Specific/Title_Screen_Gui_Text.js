#pragma strict
var tex : Transform;

function Start() {

tex.guiText.text = "ALL YOU CAN EAT";
tex.guiText.material.color = Color.red;
}